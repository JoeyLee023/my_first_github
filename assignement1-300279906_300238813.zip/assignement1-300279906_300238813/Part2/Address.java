public class Address {
    public String street;
    public int number;
    public String postal;


    //constructor
    public Address(){

    }
    public Address(String street, int number, String postal) {
        this.street = street;
        this.number = number;
        this.postal = postal;

    }
    public String getStreet(){
        return street;
    }
    public int getNumber(){
        return number;

    }
    public String getPostal(){
        return postal;

    }
    public void setStreet(String street){
        this.street = street;
    }
    public void setNumber(int number){
        this.number = number;
    }
    public void setPostal(String postal){
        this.postal = postal;
    }

    @Override
    public String toString() {
        return ("\nAddress: "+number+" " +street+ ", Postal code: " +postal);
    }
}
