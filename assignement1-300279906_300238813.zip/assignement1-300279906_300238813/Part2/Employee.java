import java.util.Arrays;
public class Employee {
    private String name;
    private int hours;
    private double rate;
    Address [] addresses;

    public Employee(){

    }
    //constructor
    public Employee(String name, int hours, double rate, Address[] addresses1 ){
        this.name = name;
        this.hours = hours;
        this.rate = rate;
        this.addresses = addresses1;

    }
    public void setName(String name){
        this.name = name;
    }
    public void setHours(int hours){
        this.hours = hours;
    }
    public void setRate(int rate){
        this.rate = rate;
    }
    public void setAddresses(Address[] addresses){
        this.addresses = addresses;
    }
    public String getName() {
        return name;
    }
    public int getHours() {
        return hours;
    }
    public double getRate() {
        return rate;
    }
    public Address[] getAddresses(){

       return addresses;
    }

    public String toString(){
        return ("Employee info "+"\nName: "+name+ "\nHours worked: "+hours+ "\nHourly rate: "+ rate +"\nAddresses: " +Arrays.toString(addresses));
    }



}
