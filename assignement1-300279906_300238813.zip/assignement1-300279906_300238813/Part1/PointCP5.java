abstract class PointCP5 {
    private char typeCoord;
    private double x;
    private double y;
    private double yOrTheta;
    private double Rho;
    private double Theta;
    abstract void convertStorageToPolar();

    abstract void convertStorageToCartesian();

    abstract double getDistance(PointCP pointB);

    abstract PointCP rotatePoint(double rotation);


    public abstract String toString();

    public double getX()
    {

        return (Math.cos(Math.toRadians(Theta)) * Rho);
    }

    public double getY()
    {

        return (Math.sin(Math.toRadians(Theta)) * Rho);
    }

    public double getRho()
    {
        return Rho;
    }

    public double getTheta()
    {

        return Theta;
    }





}
